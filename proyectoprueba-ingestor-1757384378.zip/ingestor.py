import os, re, json, boto3, pymysql
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from urllib.parse import unquote_plus

def _first_number(obj):
    if isinstance(obj, dict):
        for k in ("dolar","trm","valor","value","price","precio"):
            if k in obj:
                try: return Decimal(str(obj[k]).replace(",", "."))
                except InvalidOperation: pass
        for v in obj.values():
            n = _first_number(v)
            if n is not None: return n
    elif isinstance(obj, list):
        for v in obj:
            n = _first_number(v)
            if n is not None: return n
    elif isinstance(obj, (int, float, Decimal)):
        return Decimal(str(obj))
    elif isinstance(obj, str):
        try: return Decimal(obj.replace(",", "."))
        except InvalidOperation: return None
    return None

def _parse_val(b: bytes):
    t = b.decode("utf-8", "ignore")
    try:
        return _first_number(json.loads(t))
    except json.JSONDecodeError:
        m = re.search(r"(\d+(?:[.,]\d+)*)", t)
        if not m: return None
        try: return Decimal(m.group(1).replace(",", "."))
        except InvalidOperation: return None

def process_s3_event(event, context):
    rec = event["Records"][0]
    bucket = rec["s3"]["bucket"]["name"]
    key = unquote_plus(rec["s3"]["object"]["key"])

    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()

    m = re.search(r"dolar-(\d+)\.json$", key)
    fechahora_utc = (datetime.fromtimestamp(int(m.group(1)), tz=timezone.utc)
                     if m else datetime.now(timezone.utc))

    valor = _parse_val(body)
    if valor is None:
        raise ValueError(f"No se pudo extraer 'valor' de s3://{bucket}/{key}")

    conn = pymysql.connect(
        host=os.environ["DB_HOST"],
        user=os.environ["DB_USER"],
        password=os.environ["DB_PASSWORD"],
        database=os.environ["DB_NAME"],
        port=int(os.environ.get("DB_PORT", "3306")),
        charset="utf8mb4",
        autocommit=True,
        cursorclass=pymysql.cursors.Cursor,
    )
    with conn.cursor() as cur:
        cur.execute("""
            CREATE TABLE IF NOT EXISTS `dólar`(
              `fechahora` DATETIME NOT NULL,
              `valor` DECIMAL(18,6) NOT NULL,
              PRIMARY KEY (`fechahora`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
        """)
        cur.execute("""
            INSERT INTO `dólar` (`fechahora`,`valor`)
            VALUES (%s,%s)
            ON DUPLICATE KEY UPDATE `valor`=VALUES(`valor`);
        """, (fechahora_utc.replace(tzinfo=None), str(valor)))
    conn.close()

    return {"status":"ok","bucket":bucket,"key":key,
            "fechahora":fechahora_utc.isoformat(),"valor":str(valor)}